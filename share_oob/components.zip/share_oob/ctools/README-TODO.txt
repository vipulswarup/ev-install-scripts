This is the "ccc" build of Web Details "CCC2" library that wraps rptovis.
Consider switching to use the "amd" build instead.
Also consider if we shall move this to a maven pom module.
